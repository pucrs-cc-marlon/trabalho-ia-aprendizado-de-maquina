# Trabalho de Inteligência Artificial

## Alunos
- Marlon Baptista de Quadros
- Eurico Saldanha Lemos

## Requirements
- Python 3.5
- Nltk
- cogroo4py
- BeautifulSoup4

## How To
Para rodar o script de pré-processamento é necessário rodar o jar do código fonte cogroo4py: https://github.com/gpassero/cogroo4py com isso é possível
utilizar o cogroo para a etapa de lematização das palavras.
O Algoritmo de pre_processamento leva um tempo para realizar todas as etapas necessárias, após a conclusão do script pre_processament.py
é necessário rodar o script criar_weka_files.py para a criação dos arquivos .arff utilizados pelo Weka.

## Recursos Externos
 - https://github.com/fmaruki/Nltk-Tagger-Portuguese
 - https://github.com/gpassero/cogroo4py
